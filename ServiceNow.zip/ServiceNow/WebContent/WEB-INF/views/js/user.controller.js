var app = angular.module('myapp',["ngRoute"]);

app.config(function($routeProvider) {
    $routeProvider
    .when("/UserCreation", {
        templateUrl : "UserCreation_Anj.html"
    });
});