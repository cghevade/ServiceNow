var mymodule = angular.module('myapp',[]);

mymodule.controller('timeController',function(timeService)
{
	var timeFun=function()
	{
		document.getElementById('DateNtime').innerHTML = timeService.getTime();
		var t = setTimeout(timeFun,500);
	};
	timeFun();
});
mymodule.service('timeService',function()
{
	this.getTime = function()
	{
		var today = new Date();
		var date = today.getDate();
		var month = today.getMonth()+1;
		month = checkTime(month);
		var year = today.getYear()-100;
		var h = today.getHours();
		var m = today.getMinutes();
		var s = today.getSeconds();
		m = checkTime(m);
		s = checkTime(s);
		var time = date+"/"+month+"/"+year +","+ h + ":" + m + ":" + s;
		return time;
	};
	
	function checkTime(i) 
	{
		if (i < 10) {i = "0" + i};  // add zero in front of numbers < 10
			return i;
	};
});
