package com.spring.web.commons;

public class Settings {

}
