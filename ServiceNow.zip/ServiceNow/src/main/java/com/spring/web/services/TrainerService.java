package com.spring.web.services;

import org.springframework.stereotype.Service;

@Service
public class TrainerService {

}
