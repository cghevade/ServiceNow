package com.spring.web.dao;

import com.spring.web.model.Login;
import com.spring.web.model.User;

public interface userDao extends mainDao {

	public Login getLogin(String username,String Password) throws Exception;
	public User getUser(String username) throws Exception;
	public boolean updateUserLoginStat(String username) throws Exception;
	public int forgotUserPassword(String username) throws Exception;
	public int forgotUserPasswordStatus(String username) throws Exception;
	public int logout(String username) throws Exception;
	public boolean createUser(Login login,User user) throws Exception;
}
