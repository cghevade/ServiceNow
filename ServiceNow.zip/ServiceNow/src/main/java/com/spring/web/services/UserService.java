package com.spring.web.services;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.spring.web.model.Login;
import com.spring.web.model.User;

@Service
@Scope("session")
public class UserService {
	
}
