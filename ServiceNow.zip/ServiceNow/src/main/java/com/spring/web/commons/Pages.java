package com.spring.web.commons;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@Configuration
@PropertySource("classpath:pages.properties")
public class Pages {

	@Value("${LOGIN_PAGE_MSG}")
	private String LOGIN_PAGE_MSG;
	
	@Value("${LOGIN_PAGE_ERROR}")
	private String LOGIN_PAGE_ERROR;
	
	@Value("${FORGOT_PASSWORD_MSG}")
	private String FORGOT_PASSWORD_MSG;
	
	@Value("${RESET_PASSWORD_SUCCESS}")
	private String RESET_PASSWORD_SUCCESS;
	
	@Value("${LOGIN_PAGE_LINK}")
	private String LOGIN_PAGE_LINK;
	
	@Value("${DASHBOARD}")
	private String DASHBOARD;
	
	@Value("${CANDIDATE_ADD}")
	private String CANDIDATE_ADD;
	
	@Value("${CANDIDATE_INFO}")
	private String CANDIDATE_INFO;
	
	@Value("${CANDIDATE_HEALTH}")
	private String CANDIDATE_HEALTH;
	
	@Value("${TRAINER_ADDITION}")
	private String TRAINER_ADDITION;
	
	@Value("${TRAINER_INFO}")
	private String TRAINER_INFO;
	
	@Value("${GYM_INFO}")
	private String GYM_INFO;
	
	@Value("${GYM_INSTRUMENTS}")
	private String GYM_INSTRUMENTS;
	
	@Value("${EMPLOYEE_DETAILS}")
	private String EMPLOYEE_DETAILS;
	
	@Value("${EMPLOYEE_SALARY}")
	private String EMPLOYEE_SALARY;
	
	@Value("${GYM_EXPENSES}")
	private String GYM_EXPENSES;
	
	@Value("${EMPLOYEE_ATTENDANCE}")
	private String EMPLOYEE_ATTENDANCE;
	
	@Value("${USER_INFO_REPORT}")
	private String USER_INFO_REPORT;
	
	@Value("${CANDIDATE_INFO_REPORT}")
	private String CANDIDATE_INFO_REPORT;
	
	@Value("${CANDIDATE_HEALTH_REPORT}")
	private String CANDIDATE_HEALTH_REPORT;
	
	@Value("${TRAINER_REPORT}")
	private String TRAINER_REPORT;
	
	@Value("${GYM_REPORT}")
	private String GYM_REPORT;
	
	@Value("${GYM_INSTRUMENTS_REPORT}")
	private String GYM_INSTRUMENTS_REPORT;
	
	@Value("${GYM_EXPENSES_REPORT}")
	private String GYM_EXPENSES_REPORT;
	
	@Value("${SETTINGS}")
	private String SETTINGS;
	
	@Value("${USER_CDM}")
	private String USER_CDM;
	
	@Value("${USER_INFO}")
	private String USER_INFO;

	public String getLOGIN_PAGE_MSG() {
		return LOGIN_PAGE_MSG;
	}

	public String getLOGIN_PAGE_ERROR() {
		return LOGIN_PAGE_ERROR;
	}
	
	public String getFORGOT_PASSWORD_MSG() {
		return FORGOT_PASSWORD_MSG;
	}

	public String getRESET_PASSWORD_SUCCESS() {
		return RESET_PASSWORD_SUCCESS;
	}

	public String getLOGIN_PAGE_LINK() {
		return LOGIN_PAGE_LINK;
	}

	public String getDASHBOARD() {
		return DASHBOARD;
	}

	public String getCANDIDATE_ADD() {
		return CANDIDATE_ADD;
	}

	public String getCANDIDATE_INFO() {
		return CANDIDATE_INFO;
	}

	public String getCANDIDATE_HEALTH() {
		return CANDIDATE_HEALTH;
	}

	public String getTRAINER_ADDITION() {
		return TRAINER_ADDITION;
	}

	public String getTRAINER_INFO() {
		return TRAINER_INFO;
	}

	public String getGYM_INFO() {
		return GYM_INFO;
	}

	public String getGYM_INSTRUMENTS() {
		return GYM_INSTRUMENTS;
	}

	public String getEMPLOYEE_DETAILS() {
		return EMPLOYEE_DETAILS;
	}

	public String getEMPLOYEE_SALARY() {
		return EMPLOYEE_SALARY;
	}

	public String getGYM_EXPENSES() {
		return GYM_EXPENSES;
	}

	public String getEMPLOYEE_ATTENDANCE() {
		return EMPLOYEE_ATTENDANCE;
	}

	public String getUSER_INFO_REPORT() {
		return USER_INFO_REPORT;
	}

	public String getCANDIDATE_INFO_REPORT() {
		return CANDIDATE_INFO_REPORT;
	}

	public String getCANDIDATE_HEALTH_REPORT() {
		return CANDIDATE_HEALTH_REPORT;
	}

	public String getTRAINER_REPORT() {
		return TRAINER_REPORT;
	}

	public String getGYM_REPORT() {
		return GYM_REPORT;
	}

	public String getGYM_INSTRUMENTS_REPORT() {
		return GYM_INSTRUMENTS_REPORT;
	}

	public String getGYM_EXPENSES_REPORT() {
		return GYM_EXPENSES_REPORT;
	}

	public String getSETTINGS() {
		return SETTINGS;
	}

	public String getUSER_CDM() {
		return USER_CDM;
	}

	public String getUSER_INFO() {
		return USER_INFO;
	}

}