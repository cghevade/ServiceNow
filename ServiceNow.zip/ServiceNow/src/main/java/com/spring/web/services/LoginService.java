package com.spring.web.services;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.web.dao.userDao;
import com.spring.web.model.Login;
import com.spring.web.model.User;
import com.spring.web.securities.EncryptionDecryptionAES;

@Service
public class LoginService {

	private static final String CLASS_NAME=LoginService.class.getName();
	private static final Logger log = Logger.getLogger(CLASS_NAME);
	
	@Autowired
	private userDao userdao;
	
	@Autowired
	private EncryptionDecryptionAES encryptor;
	
	public User validateUser(Login login)
	{
		/*String pass ="";
		log.info("Before Encryption:"+login.getPassword());
		try
		{
			pass = encryptor.encrypt(login.getPassword());
			log.info("After Encryption:"+ pass);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		try
		{
			log.info("After Decryption:"+encryptor.decrypt(pass));
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}*/
		
		Login local =null;
		User user = null;
		try
		{
			local = userdao.getLogin(login.getUsername(), login.getPassword());
		}
		catch(Exception e)
		{
			local = null;
			log.error(e);
		}
		
		if(local!=null)
		{
			try
			{
				user = userdao.getUser(login.getUsername());
				if(user!=null)
				{
					log.info("User:"+user.getUsername()+" Logged Successfully");
				}
				else
				{
					user = null;
				}
			}
			catch(Exception e)
			{
				user = null;
				log.error(e);
			}
			
		}
		
		return user;
	}
	
	public boolean forgotPassword(String username)
	{
		if(!username.equalsIgnoreCase(""))
		{
			try
			{
				if(userdao.forgotUserPassword(username) == 1)
					return true;
				else
					return false;
			}
			catch(Exception e)
			{
				log.error(e);
				return false;
			}
		}
		else
		{
			return false;
		}
	}

	public void logout(String username) {

		try
		{
			int update = userdao.logout(username);
			log.info("User Logged out:" + username + " with Status:" + update);
		}
		catch(Exception e)
		{
			log.error(e);
		}
	}
	
	public void createUser(String User,String Password)
	{
		
	}

	public userDao getUserdao() {
		return userdao;
	}

	public void setUserdao(userDao userdao) {
		this.userdao = userdao;
	}

	public EncryptionDecryptionAES getEncryptor() {
		return encryptor;
	}

	public void setEncryptor(EncryptionDecryptionAES encryptor) {
		this.encryptor = encryptor;
	}

}
