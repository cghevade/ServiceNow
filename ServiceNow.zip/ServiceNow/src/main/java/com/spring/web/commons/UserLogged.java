package com.spring.web.commons;

import com.spring.web.model.Login;
import com.spring.web.model.User;

public class UserLogged {

	public static User User;
	public static Login Login;

	public static User getUser() {
		return User;
	}

	public static void setUser(User user) {
		User = user;
	}

	public static Login getLogin() {
		return Login;
	}

	public static void setLogin(Login login) {
		Login = login;
	}

}
