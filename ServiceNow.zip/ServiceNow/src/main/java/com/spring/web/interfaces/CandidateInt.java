package com.spring.web.interfaces;

public interface CandidateInt
{

}
