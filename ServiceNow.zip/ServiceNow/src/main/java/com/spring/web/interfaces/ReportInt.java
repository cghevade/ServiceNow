package com.spring.web.interfaces;

public interface ReportInt {

}
