package com.spring.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.web.commons.Pages;
import com.spring.web.interfaces.DashboardInt;
import com.spring.web.model.Login;
import com.spring.web.services.DashboardService;

@Controller
@Scope("session")
public class DashboardController implements DashboardInt {
	
	@Autowired
	DashboardService dashboarService;
	
	@Autowired
	Pages page;
	
	@Autowired
	Login login;
	
	@Autowired
	ModelAndView mavLogin;
	
	@Autowired
	ModelAndView mavDashboard;

	@RequestMapping(value="/dashboard",method=RequestMethod.GET)
	public ModelAndView getDashboardView(HttpSession session, HttpServletRequest request, HttpServletResponse response) {
		
		if(session.getAttribute("user")==null)
		{
			return displayLoginPage();
		}
		else
		{
			mavDashboard.addObject("pageName", page.getDASHBOARD());
			return mavDashboard;
		}
	}
	
	@Override
	public ModelAndView displayLoginPage() {
		mavLogin.addObject("login",login);
		mavLogin.addObject("pageName", page.getLOGIN_PAGE_MSG());
		return mavLogin;
	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}
	
}