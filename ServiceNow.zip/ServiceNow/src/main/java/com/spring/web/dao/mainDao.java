package com.spring.web.dao;

public interface mainDao {
	
	public void createSession();
	public void saveSession(boolean commit);
	public void terminateSession();
	
	/*public boolean save(Object o,boolean defaultCommit);
	public Object get(Object o,int primarykey);
	public Object get(Map<Object, Object> map);*/
}
