package com.spring.web.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;

@Entity
@Scope("session")
@Table(name="USERS")
public class User {

	@Id 
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="SRNO")
	private int SRNO;
	
	@Column(name="FIRSTNAME")
	private String firstName;
	
	@Column(name="LASTNAME")
	private String lastName;
	
	@Column(name="MAILID")
	private String mailId;
	
	@Column(name="DOB")
	private Date dob;
	
	@Column(name="MOBILE")
	private String mobileNo;
	
	@Column(name="AREA")
	private String area;
	
	@Column(name="USERNAME")
	private String username;
	
	@Column(name="ISLOGGED")
	private int isLogger;
	
	@Column(name="ISRESETPASSWORD")
	private int isResetPassword;
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getMailId() {
		return mailId;
	}
	public void setMailId(String mailId) {
		this.mailId = mailId;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getIsLogger() {
		return isLogger;
	}
	public void setIsLogger(int isLogger) {
		this.isLogger = isLogger;
	}
	public int getIsResetPassword() {
		return isResetPassword;
	}
	public void setIsResetPassword(int isResetPassword) {
		this.isResetPassword = isResetPassword;
	}
	
}
