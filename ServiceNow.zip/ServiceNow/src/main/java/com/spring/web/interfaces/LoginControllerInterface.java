package com.spring.web.interfaces;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.ModelAndView;

import com.spring.web.model.Login;

public interface LoginControllerInterface {
	
	public ModelAndView showLogin(HttpSession session, HttpServletRequest request, HttpServletResponse response);
	public ModelAndView getDashboardView(HttpSession session,HttpServletRequest request, HttpServletResponse response, @ModelAttribute("login") Login login);
	public ModelAndView logoutProcess(HttpSession session,HttpServletRequest request, HttpServletResponse response);

}
