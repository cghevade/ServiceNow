package com.spring.web.dao;

import java.util.Calendar;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.spring.web.model.Login;
import com.spring.web.model.User;

@Repository
public class UserDaoImpl implements userDao{

	private final static String CLASS_NAME = UserDaoImpl.class.getName();
	private final static Logger log = Logger.getLogger(CLASS_NAME);
	
	@Autowired
	private SessionFactory sessionFactory;
	private Session session = null;
	private Transaction transaction = null;

	@Override
	public void createSession() {
		session = getSessionFactory().openSession();
		transaction = session.beginTransaction();
	}

	@Override
	public void saveSession(boolean commit) {
		if(commit)
		{
			if(transaction.isActive()) {
				transaction.commit();
			}
		}
		
		transaction = null;
		session.close();
	}

	@Override
	public void terminateSession() {
		
		if(transaction.isActive()) {
			transaction.rollback();
		}
		
		transaction = null;
		session.close();
	}

	@Override
	public Login getLogin(String username,String Password) throws Exception {

		Login login = null;
		createSession();

		Query qryLogin = session.createQuery("from Login where username= :username and password= :userpassword");
		qryLogin.setString("username", username);
		qryLogin.setString("userpassword", Password);

		login = (Login)qryLogin.getSingleResult();

		saveSession(false);

		return login;
	}

	@Override
	public User getUser(String username) throws Exception {

		User user = null;
		createSession();

		System.out.println("user Name:"+username);
		Query qryUser = session.createQuery("from User where username= :username and islogged=0");
		qryUser.setString("username", username);
		user = (User)qryUser.getSingleResult();

		saveSession(false);

		if(user!=null) {
			updateUserLoginStat(username);
		}
		return user;
	}

	@Override
	public boolean updateUserLoginStat(String username) throws Exception{

		createSession();

		Query qryUserLoginUpdate = session.createQuery("Update User set islogged=1 where username= :username");
		qryUserLoginUpdate.setString("username", username);
		int update = qryUserLoginUpdate.executeUpdate();

		log.info("User Logged In:"+username+" with Status:"+update);

		saveSession(true);

		return true;
	}

	@Override
	public int forgotUserPassword(String username) throws Exception {

		int update = 0;
		createSession();
		
		Query qrysetBlank = session.createQuery("Update Login set password='' where username= :username");
		qrysetBlank.setString("username", username);
		update = qrysetBlank.executeUpdate();

		saveSession(true);

		if(update == 1)
			return forgotUserPasswordStatus(username);
		else
			return 0;
	}
	
	@Override
	public int forgotUserPasswordStatus(String username) throws Exception {

		int update = 0;
		createSession();
			
			Query qryForgotPassword = session.createQuery("Update User set isResetPassword=1 where username= :username");
			qryForgotPassword.setString("username", username);
			update = qryForgotPassword.executeUpdate();
			
			saveSession(true);
			
			return update;
	}
	
	@Override
	public int logout(String username) throws Exception {

		int update = 0;
		createSession();

		Query qryUserLogoutUpdate = session.createQuery("Update User set islogged=0 where username= :username and islogged=1");
		qryUserLogoutUpdate.setString("username", username);
		update = qryUserLogoutUpdate.executeUpdate();

		saveSession(true);

		return update;
	}
	
	@Override
	public boolean createUser(Login login,User user) throws Exception{
		
		return true;
	}
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public Session getSession() {
		return session;
	}

	public void setSession(Session session) {
		this.session = session;
	}

	public Transaction getTransaction() {
		return transaction;
	}

	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
}
