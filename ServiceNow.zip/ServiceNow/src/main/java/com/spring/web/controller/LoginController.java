package com.spring.web.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.spring.web.commons.Pages;
import com.spring.web.interfaces.LoginControllerInterface;
import com.spring.web.model.Login;
import com.spring.web.model.User;
import com.spring.web.services.LoginService;
import com.spring.web.services.UserService;

@Controller
@Scope("session")
public class LoginController implements LoginControllerInterface
{
	private static final String CLASS_NAME=LoginController.class.getName();
	private static final Logger log = Logger.getLogger(CLASS_NAME);
	
	@Autowired
	LoginService loginService;

	@Autowired
	Pages page;
	
	@Autowired
	Login login;
	
	@Autowired
	ModelAndView mavLogin;
	
	@Autowired
	ModelAndView mavLoginError;
	
	@Autowired
	ModelAndView mavforgotPassword;
	
	@Autowired
	ModelAndView mavDashboard;
	
	@RequestMapping(value="/",method = RequestMethod.GET)
	public ModelAndView showLogin(HttpSession session, HttpServletRequest request, HttpServletResponse response) 
	{
		Login cklogin=checkCookies(request);
		if(cklogin==null)
		{
			mavLogin.addObject("login",login);
			mavLogin.addObject("User",new User());
			mavLogin.addObject("pageName", page.getLOGIN_PAGE_MSG());
			return mavLogin;
		}
		else
		{
			User user = loginService.validateUser(cklogin);
			if (user!=null) 
			{
				session.setAttribute("username", cklogin.getUsername());
				session.setAttribute("user", user);
				mavDashboard.addObject("pageName", page.getDASHBOARD());
				return mavDashboard;
			} 
			else
			{
				mavLoginError.addObject("pageName", page.getLOGIN_PAGE_MSG());
				mavLoginError.addObject("errormessage", page.getLOGIN_PAGE_ERROR());
				return mavLoginError;
			}
		}
		
	}
	
	@RequestMapping(value = "/dashboard", method = RequestMethod.POST)
	public ModelAndView getDashboardView(HttpSession session,HttpServletRequest request, HttpServletResponse response, @ModelAttribute("login") Login login)
	{
		User user = loginService.validateUser(login);
		if (user!=null) 
		{
			session.setAttribute("username", login.getUsername());
			session.setAttribute("user", user);
			if(request.getParameter("rememberme")!=null)
			{
				Cookie ckUsername=new Cookie("username", login.getUsername());
				ckUsername.setMaxAge(3600);
				response.addCookie(ckUsername);

				Cookie ckPassword=new Cookie("password", login.getPassword());
				ckPassword.setMaxAge(3600);
				response.addCookie(ckPassword);
			}
			mavDashboard.addObject("pageName", page.getDASHBOARD());
			return mavDashboard;
		} 
		else
		{
			mavLoginError.addObject("pageName", page.getLOGIN_PAGE_MSG());
			mavLoginError.addObject("errormessage", page.getLOGIN_PAGE_ERROR());
			return mavLoginError;
		}

	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public ModelAndView logoutProcess(HttpSession session,HttpServletRequest request, HttpServletResponse response) {
		
		loginService.logout((String)session.getAttribute("username"));
		
		session.removeAttribute("username");
		session.removeAttribute("user");
		for(Cookie ck:request.getCookies())
		{
			if(ck.getName().equalsIgnoreCase("username"))
			{
				ck.setMaxAge(0);
				response.addCookie(ck);
			}
			if(ck.getName().equalsIgnoreCase("password"))
			{
				ck.setMaxAge(0);
				response.addCookie(ck);
			}
			
		}
		session.invalidate();
		mavLogin.addObject("login",login);
		mavLogin.addObject("pageName", page.getLOGIN_PAGE_MSG());
		return mavLogin;
	}
	
	@RequestMapping(value = "/forgotPassword", method = RequestMethod.GET)
	public ModelAndView forgotPassword(HttpSession session,HttpServletRequest request, HttpServletResponse response) {
		
		mavforgotPassword.addObject("pageName", page.getFORGOT_PASSWORD_MSG());
		mavforgotPassword.addObject("statusMessage", "");
		mavforgotPassword.addObject("homepagelink","");
		return mavforgotPassword;
	}
	
	@RequestMapping(value = "/resetPassword", method = RequestMethod.GET)
	public ModelAndView resetPassword(HttpSession session,HttpServletRequest request, HttpServletResponse response) {
		if(loginService.forgotPassword(request.getParameter("username")))
		{
			mavforgotPassword.addObject("pageName", page.getFORGOT_PASSWORD_MSG());
			mavforgotPassword.addObject("statusMessage", page.getRESET_PASSWORD_SUCCESS());
			mavforgotPassword.addObject("homepagelink",page.getLOGIN_PAGE_LINK());
		}
		else
		{
			mavforgotPassword.addObject("pageName", page.getFORGOT_PASSWORD_MSG());
			mavforgotPassword.addObject("statusMessage", "User Name Error");
			mavforgotPassword.addObject("homepagelink","");
		}
		return mavforgotPassword;
	}
	
	public Login checkCookies(HttpServletRequest request)
	{
		Cookie []cookies=request.getCookies();
		Login newlogin=null;
		String username="";
		String password="";
		if(cookies!=null)
		{
			for(Cookie ck:cookies)
			{
				if(ck.getName().equalsIgnoreCase("username"))
				{
					username=ck.getValue();
				}
				if(ck.getName().equalsIgnoreCase("password"))
				{
					password=ck.getValue();
				}
			}
		}
		
		if(!username.isEmpty() && !password.isEmpty())
		{
			newlogin=login;
			newlogin.setPassword(password);
			newlogin.setUsername(username);
		}
		
		return newlogin;
	}

	public Login getLogin() {
		return login;
	}

	public void setLogin(Login login) {
		this.login = login;
	}

}
